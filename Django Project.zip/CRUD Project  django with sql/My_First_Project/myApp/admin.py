from django.contrib import admin
from myApp.models import Musician, Album

# Register your models here.
admin.site.register(Musician)
admin.site.register(Album)